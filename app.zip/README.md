# lcs-services
This is the Server Side Code for Lambodar College of Science
